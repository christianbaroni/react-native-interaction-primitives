package com.rntextengine

import android.graphics.Canvas
import android.graphics.text.LineBreaker
import android.graphics.text.MeasuredText
import android.graphics.Typeface
import android.os.Build
import android.text.BoringLayout
import android.text.Layout
import android.text.Spannable
import android.text.SpannableString
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.common.assets.ReactFontManager
import com.facebook.react.uimanager.DisplayMetricsHolder
import com.facebook.react.uimanager.PixelUtil
import com.facebook.react.views.text.ReactTypefaceUtils.parseFontWeight
import java.lang.ref.WeakReference
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

internal object RNTextEngineBindings {
    private val nextHandle = AtomicLong(1)
    private val nextGlyphFieldHandle = AtomicLong(1)
    private val preparedTexts = ConcurrentHashMap<Long, PreparedTextData>()
    private val glyphFields = ConcurrentHashMap<Long, GlyphFieldData>()
    private lateinit var reactContext: ReactApplicationContext
    private val highQualityLineBreaker by lazy { buildLineBreaker(Layout.BREAK_STRATEGY_HIGH_QUALITY) }
    private val simpleLineBreaker by lazy { buildLineBreaker(Layout.BREAK_STRATEGY_SIMPLE) }
    private val balancedLineBreaker by lazy { buildLineBreaker(Layout.BREAK_STRATEGY_BALANCED) }
    private val lineBreakerConstraints = ThreadLocal<LineBreaker.ParagraphConstraints>()
    private val lineBreakerScratchBuffers = ThreadLocal<LineBreakerScratchBuffers>()

    private data class ResolvedTextStyle(
        val fallbackLineHeight: Double,
        val includeFontPadding: Boolean,
        val lineHeightPx: Float?,
        val textBreakStrategy: Int,
        val textColor: Int?,
        val textPaint: TextPaint,
    )

    private data class TextMeasureRunStyle(
        val color: String?,
        val fontFamily: String?,
        val fontSize: Double,
        val fontStyle: String?,
        val fontWeight: String?,
        val hasColor: Boolean,
        val hasFontFamily: Boolean,
        val hasFontSize: Boolean,
        val hasFontStyle: Boolean,
        val hasFontWeight: Boolean,
        val hasLetterSpacing: Boolean,
        val hasLineHeight: Boolean,
        val hasTabularNumbers: Boolean,
        val letterSpacing: Double,
        val lineHeight: Double,
        val tabularNumbers: Boolean,
    )

    private data class TextMeasureRun(
        val end: Int,
        val start: Int,
        val style: TextMeasureRunStyle,
    )

    private data class PreparedTextData(
        val hasInlineStyleRuns: Boolean,
        @Volatile var plainMeasurementChars: CharArray? = null,
        val style: ResolvedTextStyle,
        val text: String,
        val textWithLineHeight: CharSequence,
        val uniformCapHeightPx: Float?,
    )

    private class LineBreakerScratchBuffers(
        var lengths: IntArray = IntArray(8),
        var buffers: Array<CharArray?> = arrayOfNulls(8),
        var size: Int = 0,
    ) {
        fun resolve(length: Int): CharArray {
            for (index in 0 until size) {
                if (lengths[index] == length) return requireNotNull(buffers[index])
            }

            if (size == lengths.size) {
                lengths = lengths.copyOf(size * 2)
                buffers = buffers.copyOf(size * 2)
            }

            return CharArray(length).also { buffer ->
                lengths[size] = length
                buffers[size] = buffer
                size += 1
            }
        }
    }

    internal enum class TextMountMode {
        NATIVE,
        SPANNABLE,
    }

    internal data class PreparedTextViewData(
        val baseCapHeightPx: Float,
        val includeFontPadding: Boolean,
        val lineHeightPx: Float?,
        val mountMode: TextMountMode,
        val text: CharSequence,
        val textColor: Int?,
        val textPaint: TextPaint,
        val uniformCapHeightPx: Float?,
    )

    internal data class GlyphFieldVariantData(
        val textPaint: TextPaint,
        val widthCache: MutableMap<Int, Float> = HashMap(),
        val yOffset: Float,
    )

    private data class GlyphFieldRunData(
        val text: String,
        val variant: GlyphFieldVariantData,
        val variantIndex: Int,
        val width: Float,
    )

    private data class GlyphFieldRowData(
        val runs: List<GlyphFieldRunData>,
        val width: Float,
    )

    private data class GlyphFieldData(
        val columns: Int,
        @Volatile var glyphIndexBuffer: ByteBuffer? = null,
        val glyphPalette: String?,
        val lineHeightPx: Float,
        val rows: Int,
        val textAlign: String?,
        @Volatile var variantIndexBuffer: ByteBuffer? = null,
        val variants: List<GlyphFieldVariantData>,
        val views: CopyOnWriteArrayList<WeakReference<android.view.View>> = CopyOnWriteArrayList(),
        @Volatile var renderedRows: List<GlyphFieldRowData> = emptyList(),
    )

    @JvmStatic
    fun initialize(context: ReactApplicationContext) {
        reactContext = context
    }

    @JvmStatic
    fun cleanup() {
        preparedTexts.clear()
        glyphFields.clear()
        nextHandle.set(1)
        nextGlyphFieldHandle.set(1)
    }

    @JvmStatic
    fun createGlyphField(
        columns: Int,
        rows: Int,
        fontFamily: String?,
        fontSize: Double,
        glyphPalette: String?,
        letterSpacing: Double,
        lineHeight: Double,
        textAlign: String?,
        variantColors: Array<String>,
        variantFontWeights: Array<String?>,
        variantFontStyles: Array<String?>,
    ): Long {
        require(columns > 0 && rows > 0) { "RNTextEngine: glyph field columns and rows must be positive." }
        require(fontSize > 0 && lineHeight > 0) { "RNTextEngine: glyph field fontSize and lineHeight must be positive." }
        require(variantColors.isNotEmpty() && variantColors.size <= 255) {
            "RNTextEngine: glyph field variants must contain between 1 and 255 entries."
        }
        require(glyphPalette == null || (glyphPalette.isNotEmpty() && glyphPalette.length <= 256)) {
            "RNTextEngine: glyph field glyphPalette must contain between 1 and 256 UTF-16 code units."
        }
        require(variantColors.size == variantFontWeights.size && variantColors.size == variantFontStyles.size) {
            "RNTextEngine: glyph field variant arrays must stay aligned."
        }

        val variants =
            List(variantColors.size) { index ->
                val style =
                    resolveTextStyle(
                        color = variantColors[index],
                        fontFamily = fontFamily,
                        fontSize = fontSize,
                        fontWeight = variantFontWeights[index],
                        fontStyle = variantFontStyles[index],
                        letterSpacing = letterSpacing,
                        lineHeight = lineHeight,
                        allowFontScaling = false,
                        includeFontPadding = false,
                        tabularNumbers = false,
                        textBreakStrategy = null,
                    )
                val metrics = style.textPaint.fontMetrics
                GlyphFieldVariantData(
                    textPaint = style.textPaint,
                    yOffset = ((style.lineHeightPx ?: 0f) - (metrics.descent - metrics.ascent)) * 0.5f - metrics.ascent,
                )
            }

        val handle = nextGlyphFieldHandle.getAndIncrement()
        glyphFields[handle] =
            GlyphFieldData(
                columns = columns,
                glyphPalette = glyphPalette,
                lineHeightPx = PixelUtil.toPixelFromDIP(lineHeight.toFloat()),
                rows = rows,
                textAlign = textAlign,
                variants = variants,
            )
        return handle
    }

    @JvmStatic
    fun getGlyphFieldCellCount(handle: Long): Int {
        val field = glyphFields[handle] ?: error("RNTextEngine: attempted to use an invalid glyph field handle.")
        return field.columns * field.rows
    }

    @JvmStatic
    fun updateGlyphField(handle: Long, glyphs: String, variantIndices: ByteArray) {
        val field = glyphFields[handle] ?: error("RNTextEngine: attempted to use an invalid glyph field handle.")
        val cellCount = field.columns * field.rows
        require(glyphs.length == cellCount) { "RNTextEngine: glyph field glyphs length must match columns * rows." }
        require(variantIndices.size == cellCount) { "RNTextEngine: glyph field variantIndices length must match columns * rows." }
        variantIndices.forEach { variantIndex ->
            require((variantIndex.toInt() and 0xFF) < field.variants.size) {
                "RNTextEngine: glyph field variant index exceeded the configured variant count."
            }
        }

        val nextRows = buildGlyphFieldRows(field, glyphs, variantIndices)
        val dirtyRanges = buildGlyphFieldDirtyRanges(field.renderedRows, nextRows, field.rows)
        field.renderedRows = nextRows
        invalidateGlyphFieldViews(field, dirtyRanges)
    }

    @JvmStatic
    fun updateGlyphFieldIndices(handle: Long, glyphIndices: ByteArray, variantIndices: ByteArray) {
        val field = glyphFields[handle] ?: error("RNTextEngine: attempted to use an invalid glyph field handle.")
        val glyphPalette = field.glyphPalette ?: error("RNTextEngine: updateGlyphFieldIndices() requires glyphPalette on the glyph field config.")
        val cellCount = field.columns * field.rows
        require(glyphIndices.size == cellCount) { "RNTextEngine: glyph field glyphIndices length must match columns * rows." }
        require(variantIndices.size == cellCount) { "RNTextEngine: glyph field variantIndices length must match columns * rows." }
        glyphIndices.forEach { glyphIndex ->
            require((glyphIndex.toInt() and 0xFF) < glyphPalette.length) {
                "RNTextEngine: glyph field glyph index exceeded the configured glyphPalette length."
            }
        }
        variantIndices.forEach { variantIndex ->
            require((variantIndex.toInt() and 0xFF) < field.variants.size) {
                "RNTextEngine: glyph field variant index exceeded the configured variant count."
            }
        }

        val nextRows = buildGlyphFieldRowsFromIndices(field, glyphPalette, glyphIndices, variantIndices)
        val dirtyRanges = buildGlyphFieldDirtyRanges(field.renderedRows, nextRows, field.rows)
        field.renderedRows = nextRows
        invalidateGlyphFieldViews(field, dirtyRanges)
    }

    @JvmStatic
    fun attachGlyphFieldBuffers(handle: Long, glyphIndices: ByteBuffer, variantIndices: ByteBuffer) {
        val field = glyphFields[handle] ?: error("RNTextEngine: attempted to use an invalid glyph field handle.")
        val cellCount = field.columns * field.rows
        require(glyphIndices.capacity() == cellCount && variantIndices.capacity() == cellCount) {
            "RNTextEngine: glyph field buffers must match columns * rows."
        }
        field.glyphIndexBuffer = glyphIndices
        field.variantIndexBuffer = variantIndices
    }

    @JvmStatic
    fun commitGlyphFieldBuffers(handle: Long) {
        val field = glyphFields[handle] ?: error("RNTextEngine: attempted to use an invalid glyph field handle.")
        val glyphPalette = field.glyphPalette ?: error("RNTextEngine: commitGlyphFieldBuffers() requires glyphPalette on the glyph field config.")
        val glyphIndices = field.glyphIndexBuffer ?: error("RNTextEngine: attempted to use glyph field buffers before creating them.")
        val variantIndices = field.variantIndexBuffer ?: error("RNTextEngine: attempted to use glyph field buffers before creating them.")
        val cellCount = field.columns * field.rows
        require(glyphIndices.capacity() == cellCount && variantIndices.capacity() == cellCount) {
            "RNTextEngine: glyph field buffers must match columns * rows."
        }

        repeat(cellCount) { index ->
            require((glyphIndices.get(index).toInt() and 0xFF) < glyphPalette.length) {
                "RNTextEngine: glyph field glyph index exceeded the configured glyphPalette length."
            }
            require((variantIndices.get(index).toInt() and 0xFF) < field.variants.size) {
                "RNTextEngine: glyph field variant index exceeded the configured variant count."
            }
        }

        val nextRows = buildGlyphFieldRowsFromBuffers(field, glyphPalette, glyphIndices, variantIndices)
        val dirtyRanges = buildGlyphFieldDirtyRanges(field.renderedRows, nextRows, field.rows)
        field.renderedRows = nextRows
        invalidateGlyphFieldViews(field, dirtyRanges)
    }

    @JvmStatic
    fun releaseGlyphField(handle: Long) {
        glyphFields.remove(handle)
    }

    internal fun registerGlyphFieldView(handle: Long, view: android.view.View) {
        if (handle <= 0L) return
        glyphFields[handle]?.views?.add(WeakReference(view))
    }

    internal fun unregisterGlyphFieldView(handle: Long, view: android.view.View) {
        if (handle <= 0L) return
        glyphFields[handle]?.views?.removeAll { reference ->
            val candidate = reference.get()
            candidate == null || candidate === view
        }
    }

    internal fun drawGlyphField(handle: Long, canvas: Canvas, width: Float, height: Float) {
        val field = glyphFields[handle] ?: return
        if (field.renderedRows.isEmpty()) return

        val topInset = max(0f, (height - field.rows * field.lineHeightPx) * 0.5f)
        val clipBounds = canvas.clipBounds
        val startRow = max(0, floor((clipBounds.top - topInset) / field.lineHeightPx).toInt())
        val endRow = min(field.rows, ceil((clipBounds.bottom - topInset) / field.lineHeightPx).toInt())
        val rows = field.renderedRows

        for (row in startRow until endRow) {
            val rowData = rows.getOrNull(row) ?: continue
            var x =
                when (field.textAlign) {
                    "right" -> width - rowData.width
                    "center" -> (width - rowData.width) * 0.5f
                    else -> 0f
                }

            for (run in rowData.runs) {
                val baseline = topInset + row * field.lineHeightPx + run.variant.yOffset
                canvas.drawText(run.text, x, baseline, run.variant.textPaint)
                x += run.width
            }
        }
    }

    @JvmStatic
    fun prepare(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
    ): Long {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val handle = nextHandle.getAndIncrement()
        preparedTexts[handle] = buildPreparedText(text, style)
        return handle
    }

    @JvmStatic
    fun prepareTextView(
        text: String,
        textTransform: String?,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
    ): Long {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val handle = nextHandle.getAndIncrement()
        preparedTexts[handle] = buildPreparedTextForTextView(text, textTransform, style)
        return handle
    }

    @JvmStatic
    fun prepareBatch(
        texts: Array<String>,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
    ): LongArray {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )

        return LongArray(texts.size) { index ->
            val handle = nextHandle.getAndIncrement()
            preparedTexts[handle] = buildPreparedText(texts[index], style)
            handle
        }
    }

    @JvmStatic
    fun prepareWithRuns(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): Long {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runs =
            buildRuns(
                textLength = text.length,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )

        val handle = nextHandle.getAndIncrement()
        preparedTexts[handle] =
            buildPreparedText(text, baseStyle, runs) { runStyle ->
                resolveTextStyle(
                    color = if (runStyle.hasColor) runStyle.color else color,
                    fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                    fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                    fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                    fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                    letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                    lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                    allowFontScaling = allowFontScaling,
                    includeFontPadding = includeFontPadding,
                    tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                    textBreakStrategy = textBreakStrategy,
                )
            }
        return handle
    }

    @JvmStatic
    fun prepareTextViewWithRuns(
        text: String,
        textTransform: String?,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): Long {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runs =
            buildRuns(
                textLength = text.length,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )

        val handle = nextHandle.getAndIncrement()
        preparedTexts[handle] =
            buildPreparedTextForTextView(text, textTransform, baseStyle, runs) { runStyle ->
                resolveTextStyle(
                    color = if (runStyle.hasColor) runStyle.color else color,
                    fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                    fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                    fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                    fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                    letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                    lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                    allowFontScaling = allowFontScaling,
                    includeFontPadding = includeFontPadding,
                    tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                    textBreakStrategy = textBreakStrategy,
                )
            }
        return handle
    }

    @JvmStatic
    fun prepareBatchWithRuns(
        texts: Array<String>,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        runCounts: IntArray,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): LongArray {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runsByText =
            buildRunsByText(
                texts = texts,
                runCounts = runCounts,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )

        return LongArray(texts.size) { index ->
            val handle = nextHandle.getAndIncrement()
            preparedTexts[handle] =
                buildPreparedText(texts[index], baseStyle, runsByText[index]) { runStyle ->
                    resolveTextStyle(
                        color = if (runStyle.hasColor) runStyle.color else color,
                        fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                        fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                        fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                        fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                        letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                        lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                        allowFontScaling = allowFontScaling,
                        includeFontPadding = includeFontPadding,
                        tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                        textBreakStrategy = textBreakStrategy,
                    )
                }
            handle
        }
    }

    @JvmStatic
    fun release(handle: Long) {
        preparedTexts.remove(handle)
    }

    @JvmStatic
    fun releaseMany(handles: LongArray) {
        handles.forEach { handle ->
            preparedTexts.remove(handle)
        }
    }

    @JvmStatic
    fun measurePreparedWidth(handle: Long): Double {
        return measureIntrinsicWidth(requirePrepared(handle))
    }

    @JvmStatic
    fun measureWidth(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
    ): Double {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val prepared = buildPreparedText(text, style)
        return measureIntrinsicWidth(prepared)
    }

    @JvmStatic
    fun measureWidthWithRuns(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): Double {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runs =
            buildRuns(
                textLength = text.length,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )
        val prepared =
            buildPreparedText(text, baseStyle, runs) { runStyle ->
                resolveTextStyle(
                    color = if (runStyle.hasColor) runStyle.color else color,
                    fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                    fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                    fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                    fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                    letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                    lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                    allowFontScaling = allowFontScaling,
                    includeFontPadding = includeFontPadding,
                    tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                    textBreakStrategy = textBreakStrategy,
                )
            }
        return measureIntrinsicWidth(prepared)
    }

    @JvmStatic
    fun measure(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        width: Double,
        maxLines: Int,
        ellipsizeMode: String?,
        anchorToCapHeight: Boolean,
    ): DoubleArray {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val prepared = buildPreparedText(text, style)
        return packLayout(buildLayout(prepared, width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = false))
    }

    @JvmStatic
    fun measureWithRuns(
        text: String,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        width: Double,
        maxLines: Int,
        ellipsizeMode: String?,
        anchorToCapHeight: Boolean,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): DoubleArray {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runs =
            buildRuns(
                textLength = text.length,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )
        val prepared =
            buildPreparedText(text, baseStyle, runs) { runStyle ->
                resolveTextStyle(
                    color = if (runStyle.hasColor) runStyle.color else color,
                    fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                    fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                    fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                    fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                    letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                    lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                    allowFontScaling = allowFontScaling,
                    includeFontPadding = includeFontPadding,
                    tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                    textBreakStrategy = textBreakStrategy,
                )
            }
        return packLayout(buildLayout(prepared, width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = false))
    }

    @JvmStatic
    fun measureBatch(
        texts: Array<String>,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        width: Double,
        maxLines: Int,
        ellipsizeMode: String?,
        anchorToCapHeight: Boolean,
    ): DoubleArray {
        val style = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val packed = DoubleArray(texts.size * PACKED_LAYOUT_SIZE)
        texts.forEachIndexed { index, text ->
            packLayoutInto(
                packed,
                index * PACKED_LAYOUT_SIZE,
                buildLayout(buildPreparedText(text, style), width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = false),
            )
        }
        return packed
    }

    @JvmStatic
    fun measureBatchWithRuns(
        texts: Array<String>,
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        width: Double,
        maxLines: Int,
        ellipsizeMode: String?,
        anchorToCapHeight: Boolean,
        runCounts: IntArray,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): DoubleArray {
        val baseStyle = resolveTextStyle(
            color = color,
            fontFamily = fontFamily,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            allowFontScaling = allowFontScaling,
            includeFontPadding = includeFontPadding,
            tabularNumbers = tabularNumbers,
            textBreakStrategy = textBreakStrategy,
        )
        val runsByText =
            buildRunsByText(
                texts = texts,
                runCounts = runCounts,
                runStarts = runStarts,
                runEnds = runEnds,
                runStyleMasks = runStyleMasks,
                runColors = runColors,
                runFontFamilies = runFontFamilies,
                runFontSizes = runFontSizes,
                runFontWeights = runFontWeights,
                runFontStyles = runFontStyles,
                runLetterSpacings = runLetterSpacings,
                runLineHeights = runLineHeights,
                runTabularNumbers = runTabularNumbers,
            )
        val packed = DoubleArray(texts.size * PACKED_LAYOUT_SIZE)
        texts.forEachIndexed { index, text ->
            packLayoutInto(
                packed,
                index * PACKED_LAYOUT_SIZE,
                buildLayout(
                    buildPreparedText(text, baseStyle, runsByText[index]) { runStyle ->
                        resolveTextStyle(
                            color = if (runStyle.hasColor) runStyle.color else color,
                            fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                            fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                            fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                            fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                            letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                            lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                            allowFontScaling = allowFontScaling,
                            includeFontPadding = includeFontPadding,
                            tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                            textBreakStrategy = textBreakStrategy,
                        )
                    },
                    width,
                    maxLines,
                    ellipsizeMode,
                    anchorToCapHeight,
                    includeLines = false,
                ),
            )
        }
        return packed
    }

    @JvmStatic
    fun layout(handle: Long, width: Double, maxLines: Int, ellipsizeMode: String?, anchorToCapHeight: Boolean): DoubleArray {
        val prepared = requirePrepared(handle)
        return packLayout(buildLayout(prepared, width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = false))
    }

    @JvmStatic
    fun layoutBatch(handles: LongArray, width: Double, maxLines: Int, ellipsizeMode: String?, anchorToCapHeight: Boolean): DoubleArray {
        val packed = DoubleArray(handles.size * PACKED_LAYOUT_SIZE)
        handles.forEachIndexed { index, handle ->
            packLayoutInto(
                packed,
                index * PACKED_LAYOUT_SIZE,
                buildLayout(requirePrepared(handle), width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = false),
            )
        }
        return packed
    }

    @JvmStatic
    fun layoutLines(handle: Long, width: Double, maxLines: Int, ellipsizeMode: String?, anchorToCapHeight: Boolean): DoubleArray {
        val prepared = requirePrepared(handle)
        return packLayoutWithLines(buildLayout(prepared, width, maxLines, ellipsizeMode, anchorToCapHeight, includeLines = true))
    }

    @JvmStatic
    fun layoutNextLine(handle: Long, start: Int, width: Double, anchorToCapHeight: Boolean): DoubleArray? {
        val prepared = requirePrepared(handle)
        val queryStart = resolveNextLineStart(prepared.text, start)
        if (queryStart < 0) return null
        resolvePlainNextLine(prepared, queryStart, width, anchorToCapHeight)?.let { return it }

        val text: CharSequence = if (prepared.hasInlineStyleRuns) prepared.textWithLineHeight else prepared.text
        if (queryStart >= text.length) return null

        val density = currentDensity()
        val layoutWidth = max(0.0, width) * density
        val textWidthPx = max(1, ceil(layoutWidth).toInt())
        val paint = if (prepared.hasInlineStyleRuns) TextPaint(prepared.style.textPaint) else prepared.style.textPaint
        val layoutEnd = resolveNextLineContextEnd(text, paint, queryStart, textWidthPx)
        val layout =
            buildStaticLayout(
                text = text,
                paint = paint,
                widthPx = textWidthPx,
                style = prepared.style,
                maxLines = 1,
                ellipsizeMode = "clip",
                start = queryStart,
                end = layoutEnd,
            )
        if (layout.lineCount == 0) return null

        val capHeightTopInsetPx =
            if (anchorToCapHeight) {
                val defaultCapHeightPx = measureCapHeightPx(paint)
                resolveCapHeightInsetsPx(
                    layout = layout,
                    text = text,
                    defaultCapHeightPx = defaultCapHeightPx,
                    uniformCapHeightPx = prepared.uniformCapHeightPx ?: resolveUniformCapHeightPx(text, defaultCapHeightPx),
                ).top
            } else {
                0f
            }

        val lineStart = layout.getLineStart(0)
        val lineEnd = trimVisibleEnd(text, lineStart, layout.getLineVisibleEnd(0))
        val lineWidth =
            if (prepared.hasInlineStyleRuns) {
                resolveMeasuredLineWidthPx(layout, text, 0).toDouble() / density
            } else {
                resolvePlainTextLineWidthPx(paint, prepared.text, lineStart, lineEnd).toDouble() / density
            }
        val lineBottom =
            if (anchorToCapHeight) {
                (layout.getLineBaseline(0) - capHeightTopInsetPx).toDouble() / density
            } else if (!prepared.hasInlineStyleRuns && prepared.style.lineHeightPx != null) {
                prepared.style.lineHeightPx.toDouble() / density
            } else {
                layout.getLineBottom(0).toDouble() / density
            }

        return doubleArrayOf(lineStart.toDouble(), lineEnd.toDouble(), lineWidth, lineBottom)
    }

    private fun resolvePlainNextLine(
        prepared: PreparedTextData,
        start: Int,
        width: Double,
        anchorToCapHeight: Boolean,
    ): DoubleArray? {
        if (prepared.hasInlineStyleRuns || prepared.style.includeFontPadding) return null
        if (start < 0 || start >= prepared.text.length) return null

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null

        val density = currentDensity()
        val widthPx = max(1, ceil(max(0.0, width) * density).toInt())
        val paint = prepared.style.textPaint
        val measurementChars = resolvePlainMeasurementChars(prepared)
        val contextEnd = resolveLineBreakerContextEnd(prepared.text, measurementChars, paint, start, widthPx)
        val lineRangeChars = resolveLineBreakerMeasurementChars(measurementChars, start, contextEnd)
        val measuredTextBuilder = MeasuredText.Builder(lineRangeChars).setComputeLayout(false)
        if (Build.VERSION.SDK_INT >= 33) {
            measuredTextBuilder.setComputeHyphenation(MeasuredText.Builder.HYPHENATION_MODE_FAST)
        } else {
            @Suppress("DEPRECATION")
            measuredTextBuilder.setComputeHyphenation(true)
        }
        val measuredText =
            measuredTextBuilder
                .appendStyleRun(paint, lineRangeChars.size, false)
                .build()
        val constraints = resolveLineBreakerConstraints(widthPx)
        val result = resolveLineBreaker(prepared.style.textBreakStrategy).computeLineBreaks(measuredText, constraints, 0)
        if (result.lineCount == 0) return null
        val rawLineEnd = min(prepared.text.length, start + result.getLineBreakOffset(0))
        val lineEnd = trimVisibleEnd(prepared.text, start, rawLineEnd)
        val lineWidthPx = resolvePlainTextLineWidthPx(paint, measurementChars, start, lineEnd)
        val lineBottomPx =
            if (anchorToCapHeight) {
                measureCapHeightPx(paint)
            } else {
                prepared.style.lineHeightPx ?: (prepared.style.fallbackLineHeight * density).toFloat()
            }

        return doubleArrayOf(
            start.toDouble(),
            lineEnd.toDouble(),
            lineWidthPx.toDouble() / density,
            lineBottomPx.toDouble() / density,
        )
    }

    private fun resolveLineBreaker(breakStrategy: Int): LineBreaker {
        return when (breakStrategy) {
            Layout.BREAK_STRATEGY_SIMPLE -> simpleLineBreaker
            Layout.BREAK_STRATEGY_BALANCED -> balancedLineBreaker
            else -> highQualityLineBreaker
        }
    }

    private fun buildLineBreaker(breakStrategy: Int): LineBreaker {
        return LineBreaker.Builder()
            .setBreakStrategy(breakStrategy)
            .setHyphenationFrequency(LineBreaker.HYPHENATION_FREQUENCY_NORMAL)
            .build()
    }

    private fun resolveNextLineStart(text: String, start: Int): Int {
        if (start < 0 || start >= text.length) return -1

        var lineStart = start
        while (lineStart < text.length) {
            val char = text[lineStart]
            if (char == '\n' || char == '\r') {
                lineStart += 1
                continue
            }

            val followsExplicitBreak = lineStart > 0 && (text[lineStart - 1] == '\n' || text[lineStart - 1] == '\r')
            if (!followsExplicitBreak && lineStart > start && char.isWhitespace()) {
                lineStart += 1
                continue
            }

            if (!followsExplicitBreak && lineStart == start && char.isWhitespace() && start > 0) {
                lineStart += 1
                continue
            }

            break
        }

        return if (lineStart >= text.length) -1 else lineStart
    }

    private fun resolveLineBreakerContextEnd(
        text: String,
        measurementChars: CharArray,
        paint: TextPaint,
        start: Int,
        widthPx: Int,
    ): Int {
        val hardBreakIndex = text.indexOf('\n', start).let { if (it == -1) text.length else it + 1 }
        val measuredCount = paint.breakText(measurementChars, start, measurementChars.size - start, widthPx.toFloat(), null).coerceAtLeast(1)
        var end = min(hardBreakIndex, start + measuredCount)
        var remainingBoundaries = 3

        while (end < hardBreakIndex) {
            val previous = text[end - 1]
            if (previous == '\n' || previous == '\r' || previous == '.' || previous == '!' || previous == '?') break
            if (!previous.isWhitespace() && text[end].isWhitespace()) {
                remainingBoundaries -= 1
                while (end < hardBreakIndex && text[end].isWhitespace()) {
                    end += 1
                }
                if (remainingBoundaries <= 0 || end >= hardBreakIndex) break
                continue
            }
            end += 1
        }

        return end
    }
    private fun resolveNextLineContextEnd(
        text: CharSequence,
        paint: TextPaint,
        start: Int,
        widthPx: Int,
    ): Int {
        if (start >= text.length) return text.length

        val measuredCount = paint.breakText(text, start, text.length, true, widthPx.toFloat(), null).coerceAtLeast(1)
        var end = min(text.length, start + measuredCount)

        while (end < text.length) {
            val char = text[end - 1]
            if (char == '\n' || char == '\r' || char == '.' || char == '!' || char == '?') break
            end += 1
        }

        while (end < text.length && text[end].isWhitespace()) {
            end += 1
        }

        return end
    }

    private fun resolvePlainTextLineWidthPx(paint: TextPaint, text: String, start: Int, end: Int): Float {
        if (end <= start) return 0f
        val measuredWidth = paint.getRunAdvance(text, start, end, start, end, false, end)
        return roundMeasuredTextWidthPx(measuredWidth)
    }

    private fun resolvePlainTextLineWidthPx(paint: TextPaint, text: CharArray, start: Int, end: Int): Float {
        if (end <= start) return 0f
        val measuredWidth = paint.getRunAdvance(text, start, end, start, end, false, end)
        return roundMeasuredTextWidthPx(measuredWidth)
    }

    private fun buildGlyphFieldRows(field: GlyphFieldData, glyphs: String, variantIndices: ByteArray): List<GlyphFieldRowData> {
        val rows = ArrayList<GlyphFieldRowData>(field.rows)

        repeat(field.rows) { row ->
            val runs = ArrayList<GlyphFieldRunData>()
            val rowStart = row * field.columns
            var rowWidth = 0f
            var runText = StringBuilder(field.columns)
            var runVariantIndex = -1
            var runVariant: GlyphFieldVariantData? = null
            var runWidth = 0f

            fun flushRun() {
                val variant = runVariant ?: return
                if (runText.isEmpty()) return

                runs +=
                    GlyphFieldRunData(
                        text = runText.toString(),
                        variant = variant,
                        variantIndex = runVariantIndex,
                        width = runWidth,
                    )
                rowWidth += runWidth
                runText = StringBuilder(field.columns)
                runVariantIndex = -1
                runVariant = null
                runWidth = 0f
            }

            repeat(field.columns) { column ->
                val cellIndex = rowStart + column
                val glyph = glyphs[cellIndex]
                val variantIndex = variantIndices[cellIndex].toInt() and 0xFF
                val variant = field.variants[variantIndex]

                if (runVariantIndex != variantIndex) {
                    flushRun()
                    runVariantIndex = variantIndex
                    runVariant = variant
                }

                runText.append(glyph)
                runWidth += measureGlyphWidth(variant, glyph)
            }

            flushRun()
            rows += GlyphFieldRowData(runs = runs, width = rowWidth)
        }

        return rows
    }

    private fun buildGlyphFieldRowsFromIndices(
        field: GlyphFieldData,
        glyphPalette: String,
        glyphIndices: ByteArray,
        variantIndices: ByteArray,
    ): List<GlyphFieldRowData> {
        val rows = ArrayList<GlyphFieldRowData>(field.rows)

        repeat(field.rows) { row ->
            val runs = ArrayList<GlyphFieldRunData>()
            val rowStart = row * field.columns
            var rowWidth = 0f
            var runText = StringBuilder(field.columns)
            var runVariantIndex = -1
            var runVariant: GlyphFieldVariantData? = null
            var runWidth = 0f

            fun flushRun() {
                val variant = runVariant ?: return
                if (runText.isEmpty()) return

                runs +=
                    GlyphFieldRunData(
                        text = runText.toString(),
                        variant = variant,
                        variantIndex = runVariantIndex,
                        width = runWidth,
                    )
                rowWidth += runWidth
                runText = StringBuilder(field.columns)
                runVariantIndex = -1
                runVariant = null
                runWidth = 0f
            }

            repeat(field.columns) { column ->
                val cellIndex = rowStart + column
                val glyphIndex = glyphIndices[cellIndex].toInt() and 0xFF
                val glyph = glyphPalette[glyphIndex]
                val variantIndex = variantIndices[cellIndex].toInt() and 0xFF
                val variant = field.variants[variantIndex]

                if (runVariantIndex != variantIndex) {
                    flushRun()
                    runVariantIndex = variantIndex
                    runVariant = variant
                }

                runText.append(glyph)
                runWidth += measureGlyphWidth(variant, glyph)
            }

            flushRun()
            rows += GlyphFieldRowData(runs = runs, width = rowWidth)
        }

        return rows
    }

    private fun buildGlyphFieldRowsFromBuffers(
        field: GlyphFieldData,
        glyphPalette: String,
        glyphIndices: ByteBuffer,
        variantIndices: ByteBuffer,
    ): List<GlyphFieldRowData> {
        val rows = ArrayList<GlyphFieldRowData>(field.rows)

        repeat(field.rows) { row ->
            val runs = ArrayList<GlyphFieldRunData>()
            val rowStart = row * field.columns
            var rowWidth = 0f
            var runText = StringBuilder(field.columns)
            var runVariantIndex = -1
            var runVariant: GlyphFieldVariantData? = null
            var runWidth = 0f

            fun flushRun() {
                val variant = runVariant ?: return
                if (runText.isEmpty()) return

                runs +=
                    GlyphFieldRunData(
                        text = runText.toString(),
                        variant = variant,
                        variantIndex = runVariantIndex,
                        width = runWidth,
                    )
                rowWidth += runWidth
                runText = StringBuilder(field.columns)
                runVariantIndex = -1
                runVariant = null
                runWidth = 0f
            }

            repeat(field.columns) { column ->
                val cellIndex = rowStart + column
                val glyphIndex = glyphIndices.get(cellIndex).toInt() and 0xFF
                val glyph = glyphPalette[glyphIndex]
                val variantIndex = variantIndices.get(cellIndex).toInt() and 0xFF
                val variant = field.variants[variantIndex]

                if (runVariantIndex != variantIndex) {
                    flushRun()
                    runVariantIndex = variantIndex
                    runVariant = variant
                }

                runText.append(glyph)
                runWidth += measureGlyphWidth(variant, glyph)
            }

            flushRun()
            rows += GlyphFieldRowData(runs = runs, width = rowWidth)
        }

        return rows
    }

    private fun buildGlyphFieldDirtyRanges(
        previousRows: List<GlyphFieldRowData>,
        nextRows: List<GlyphFieldRowData>,
        rowCount: Int,
    ): List<IntRange> {
        val dirtyRanges = ArrayList<IntRange>()
        var rangeStart = -1

        repeat(rowCount) { row ->
            val previousRow = previousRows.getOrNull(row)
            val nextRow = nextRows.getOrNull(row)
            val didChange = previousRow != nextRow

            if (didChange && rangeStart == -1) {
                rangeStart = row
                return@repeat
            }

            if (!didChange && rangeStart != -1) {
                dirtyRanges += rangeStart until row
                rangeStart = -1
            }
        }

        if (rangeStart != -1) {
            dirtyRanges += rangeStart until rowCount
        }

        return dirtyRanges
    }

    private fun invalidateGlyphFieldViews(field: GlyphFieldData, dirtyRanges: List<IntRange>) {
        if (dirtyRanges.isEmpty()) return

        field.views.removeAll { reference ->
            val view = reference.get()
            if (view == null) {
                true
            } else {
                val shouldInvalidateWholeView =
                    dirtyRanges.size == 1 && dirtyRanges.first().first == 0 && dirtyRanges.first().last + 1 >= field.rows

                if (shouldInvalidateWholeView || view.height <= 0 || view.width <= 0) {
                    view.postInvalidateOnAnimation()
                } else {
                    val topInset = max(0f, (view.height - field.rows * field.lineHeightPx) * 0.5f)
                    dirtyRanges.forEach { rows ->
                        val top = floor(topInset + rows.first * field.lineHeightPx).toInt().coerceAtLeast(0)
                        val bottom = ceil(topInset + (rows.last + 1) * field.lineHeightPx).toInt().coerceAtMost(view.height)
                        view.postInvalidateOnAnimation(0, top, view.width, bottom)
                    }
                }
                false
            }
        }
    }

    private fun measureGlyphWidth(variant: GlyphFieldVariantData, glyph: Char): Float {
        val codePoint = glyph.code
        return variant.widthCache.getOrPut(codePoint) {
            variant.textPaint.measureText(glyph.toString())
        }
    }

    private fun resolveTextStyle(
        color: String?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
    ): ResolvedTextStyle {
        val textPaint = TextPaint(TextPaint.ANTI_ALIAS_FLAG)
        val effectiveFontSize = scale(fontSize, allowFontScaling, defaultValue = 14.0)
        textPaint.textSize = effectiveFontSize

        val resolvedColor = resolveTextColor(color)
        if (resolvedColor != null) {
            textPaint.color = resolvedColor
        }

        val typeface = resolveTypeface(fontFamily, fontWeight, fontStyle)
        textPaint.typeface = typeface

        if (!letterSpacing.isNaN() && effectiveFontSize > 0f) {
            textPaint.letterSpacing = scale(letterSpacing, allowFontScaling, defaultValue = 0.0) / effectiveFontSize
        }

        if (tabularNumbers) {
            textPaint.fontFeatureSettings = "'tnum'"
        }

        val fallbackLineHeight = if (lineHeight.isNaN()) {
            ((-textPaint.fontMetricsInt.ascent) + textPaint.fontMetricsInt.descent).toDouble().toDp()
        } else {
            scale(lineHeight, allowFontScaling, defaultValue = lineHeight).toDouble().toDp()
        }

        return ResolvedTextStyle(
            fallbackLineHeight = fallbackLineHeight,
            includeFontPadding = includeFontPadding,
            lineHeightPx = if (lineHeight.isNaN()) null else scale(lineHeight, allowFontScaling, defaultValue = lineHeight),
            textBreakStrategy = resolveTextBreakStrategy(textBreakStrategy),
            textColor = resolvedColor,
            textPaint = textPaint,
        )
    }

    private fun buildPreparedText(text: String, style: ResolvedTextStyle): PreparedTextData {
        val textWithLineHeight =
            if (style.lineHeightPx == null || text.isEmpty()) {
                text
            } else {
                SpannableString(text).apply {
                    setSpan(
                        RNTextEngineLineHeightSpan(style.lineHeightPx),
                        0,
                        text.length,
                        Spannable.SPAN_INCLUSIVE_INCLUSIVE,
                    )
                }
            }

        return PreparedTextData(
            hasInlineStyleRuns = false,
            plainMeasurementChars = null,
            style = style,
            text = text,
            textWithLineHeight = textWithLineHeight,
            uniformCapHeightPx = null,
        )
    }

    private fun buildPreparedTextForTextView(
        text: String,
        textTransform: String?,
        style: ResolvedTextStyle,
    ): PreparedTextData {
        return buildPreparedText(applyTextTransform(text, textTransform), style)
    }

    private fun buildPreparedText(
        text: String,
        style: ResolvedTextStyle,
        runs: List<TextMeasureRun>,
        resolveRunStyle: (TextMeasureRunStyle) -> ResolvedTextStyle,
    ): PreparedTextData {
        val styledText =
            if (text.isEmpty()) {
                StyledTextData(text = text, uniformCapHeightPx = null)
            } else {
                buildStyledText(text, style, runs, resolveRunStyle)
            }

        return PreparedTextData(
            hasInlineStyleRuns = runs.isNotEmpty(),
            plainMeasurementChars = null,
            style = style,
            text = text,
            textWithLineHeight = styledText.text,
            uniformCapHeightPx = styledText.uniformCapHeightPx,
        )
    }

    private fun resolvePlainMeasurementChars(prepared: PreparedTextData): CharArray {
        prepared.plainMeasurementChars?.let { return it }

        val chars = prepared.text.toCharArray()
        prepared.plainMeasurementChars = chars
        return chars
    }

    private fun resolveLineBreakerMeasurementChars(source: CharArray, start: Int, end: Int): CharArray {
        val length = max(0, end - start)
        val scratchBuffers =
            lineBreakerScratchBuffers.get()
                ?: LineBreakerScratchBuffers().also { lineBreakerScratchBuffers.set(it) }
        val target = scratchBuffers.resolve(length)
        System.arraycopy(source, start, target, 0, length)
        return target
    }

    private fun resolveLineBreakerConstraints(widthPx: Int): LineBreaker.ParagraphConstraints {
        val constraints =
            lineBreakerConstraints.get()
                ?: LineBreaker.ParagraphConstraints().also { lineBreakerConstraints.set(it) }
        constraints.setWidth(widthPx.toFloat())
        return constraints
    }

    private fun buildPreparedTextForTextView(
        text: String,
        textTransform: String?,
        style: ResolvedTextStyle,
        runs: List<TextMeasureRun>,
        resolveRunStyle: (TextMeasureRunStyle) -> ResolvedTextStyle,
    ): PreparedTextData {
        if (runs.isEmpty()) return buildPreparedTextForTextView(text, textTransform, style)

        val boundaries = ArrayList<Int>(runs.size * 2)
        runs.forEach { run ->
            boundaries.add(run.start)
            boundaries.add(run.end)
        }
        val transformed = transformText(text, textTransform, boundaries)
        val transformedRuns =
            runs.map { run ->
                run.copy(
                    start = transformed.offsetsByOriginal[run.start] ?: run.start,
                    end = transformed.offsetsByOriginal[run.end] ?: run.end,
                )
            }

        return buildPreparedText(transformed.text, style, transformedRuns, resolveRunStyle)
    }

    private fun buildStyledText(
        text: String,
        baseStyle: ResolvedTextStyle,
        runs: List<TextMeasureRun>,
        resolveRunStyle: (TextMeasureRunStyle) -> ResolvedTextStyle,
    ): StyledTextData {
        val styledText = SpannableString(text)

        if (baseStyle.lineHeightPx != null) {
            applyBaseLineHeightSpans(styledText, text.length, baseStyle.lineHeightPx, runs)
        }

        runs.forEach { run ->
            val runStyle = resolveRunStyle(run.style)
            styledText.setSpan(
                RNTextEngineTextPaintSpan(runStyle.textPaint),
                run.start,
                run.end,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
            )

            runStyle.lineHeightPx?.let { lineHeightPx ->
                styledText.setSpan(
                    RNTextEngineLineHeightSpan(lineHeightPx),
                    run.start,
                    run.end,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
                )
            }
        }

        return StyledTextData(
            text = styledText,
            uniformCapHeightPx = null,
        )
    }

    private fun applyBaseLineHeightSpans(
        styledText: SpannableString,
        textLength: Int,
        lineHeightPx: Float,
        runs: List<TextMeasureRun>,
    ) {
        var cursor = 0

        runs.forEach { run ->
            if (run.style.hasLineHeight && cursor < run.start) {
                styledText.setSpan(
                    RNTextEngineLineHeightSpan(lineHeightPx),
                    cursor,
                    run.start,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
                )
            }

            if (run.style.hasLineHeight) {
                cursor = run.end
            }
        }

        if (cursor < textLength) {
            styledText.setSpan(
                RNTextEngineLineHeightSpan(lineHeightPx),
                cursor,
                textLength,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
        }
    }

    private fun buildRuns(
        textLength: Int,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): List<TextMeasureRun> {
        requireAlignedRunArrays(
            runStarts.size,
            runEnds.size,
            runStyleMasks.size,
            runColors.size,
            runFontFamilies.size,
            runFontSizes.size,
            runFontWeights.size,
            runFontStyles.size,
            runLetterSpacings.size,
            runLineHeights.size,
            runTabularNumbers.size,
        )

        return buildRuns(
            textLength = textLength,
            runOffset = 0,
            runCount = runStarts.size,
            runStarts = runStarts,
            runEnds = runEnds,
            runStyleMasks = runStyleMasks,
            runColors = runColors,
            runFontFamilies = runFontFamilies,
            runFontSizes = runFontSizes,
            runFontWeights = runFontWeights,
            runFontStyles = runFontStyles,
            runLetterSpacings = runLetterSpacings,
            runLineHeights = runLineHeights,
            runTabularNumbers = runTabularNumbers,
        )
    }

    private fun buildRuns(
        textLength: Int,
        runOffset: Int,
        runCount: Int,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): List<TextMeasureRun> {
        val runs = ArrayList<TextMeasureRun>(runCount)
        var previousEnd = 0

        for (relativeIndex in 0 until runCount) {
            val index = runOffset + relativeIndex
            val start = runStarts[index]
            val end = runEnds[index]
            val styleMask = runStyleMasks[index]

            require(styleMask != 0) { "RNTextEngine: each text run must override at least one inline style field." }
            require(start >= 0 && end <= textLength && end > start) {
                "RNTextEngine: text runs must stay within the source text and have positive length."
            }
            require(start >= previousEnd) { "RNTextEngine: text runs must be sorted and non-overlapping." }

            runs.add(
                TextMeasureRun(
                    end = end,
                    start = start,
                    style =
                        TextMeasureRunStyle(
                            color = runColors[index],
                            fontFamily = runFontFamilies[index],
                            fontSize = runFontSizes[index],
                            fontStyle = runFontStyles[index],
                            fontWeight = runFontWeights[index],
                            hasColor = styleMask and RUN_STYLE_HAS_COLOR != 0,
                            hasFontFamily = styleMask and RUN_STYLE_HAS_FONT_FAMILY != 0,
                            hasFontSize = styleMask and RUN_STYLE_HAS_FONT_SIZE != 0,
                            hasFontStyle = styleMask and RUN_STYLE_HAS_FONT_STYLE != 0,
                            hasFontWeight = styleMask and RUN_STYLE_HAS_FONT_WEIGHT != 0,
                            hasLetterSpacing = styleMask and RUN_STYLE_HAS_LETTER_SPACING != 0,
                            hasLineHeight = styleMask and RUN_STYLE_HAS_LINE_HEIGHT != 0,
                            hasTabularNumbers = styleMask and RUN_STYLE_HAS_TABULAR_NUMBERS != 0,
                            letterSpacing = runLetterSpacings[index],
                            lineHeight = runLineHeights[index],
                            tabularNumbers = runTabularNumbers[index],
                        ),
                ),
            )
            previousEnd = end
        }

        return runs
    }

    private fun buildRunsByText(
        texts: Array<String>,
        runCounts: IntArray,
        runStarts: IntArray,
        runEnds: IntArray,
        runStyleMasks: IntArray,
        runColors: Array<String?>,
        runFontFamilies: Array<String?>,
        runFontSizes: DoubleArray,
        runFontWeights: Array<String?>,
        runFontStyles: Array<String?>,
        runLetterSpacings: DoubleArray,
        runLineHeights: DoubleArray,
        runTabularNumbers: BooleanArray,
    ): List<List<TextMeasureRun>> {
        require(runCounts.size == texts.size) { "RNTextEngine: batch text runs must align with the batch text input length." }
        val totalRunCount = runCounts.sum()
        requireAlignedRunArrays(
            totalRunCount,
            runEnds.size,
            runStyleMasks.size,
            runColors.size,
            runFontFamilies.size,
            runFontSizes.size,
            runFontWeights.size,
            runFontStyles.size,
            runLetterSpacings.size,
            runLineHeights.size,
            runTabularNumbers.size,
        )

        val runsByText = ArrayList<List<TextMeasureRun>>(texts.size)
        var runOffset = 0

        texts.forEachIndexed { index, text ->
            val runCount = runCounts[index]
            runsByText.add(
                buildRuns(
                    textLength = text.length,
                    runOffset = runOffset,
                    runCount = runCount,
                    runStarts = runStarts,
                    runEnds = runEnds,
                    runStyleMasks = runStyleMasks,
                    runColors = runColors,
                    runFontFamilies = runFontFamilies,
                    runFontSizes = runFontSizes,
                    runFontWeights = runFontWeights,
                    runFontStyles = runFontStyles,
                    runLetterSpacings = runLetterSpacings,
                    runLineHeights = runLineHeights,
                    runTabularNumbers = runTabularNumbers,
                ),
            )
            runOffset += runCount
        }

        return runsByText
    }

    private fun requireAlignedRunArrays(expectedSize: Int, vararg actualSizes: Int) {
        actualSizes.forEach { actualSize ->
            require(actualSize == expectedSize) { "RNTextEngine: run payload arrays must stay aligned." }
        }
    }

    private data class LineInfo(
        val bottom: Double,
        val end: Double,
        val start: Double,
        val width: Double,
    )

    private data class LayoutInfo(
        val height: Double,
        val lastLineWidth: Double,
        val lineCount: Double,
        val lines: List<LineInfo>,
        val width: Double,
    )

    private data class StyledTextData(
        val text: CharSequence,
        val uniformCapHeightPx: Float?,
    )

    private fun trimVisibleEnd(text: CharSequence, start: Int, end: Int): Int {
        var visibleEnd = end

        while (visibleEnd > start && text[visibleEnd - 1].isWhitespace()) {
            visibleEnd -= 1
        }

        return visibleEnd
    }

    private fun buildLayout(
        prepared: PreparedTextData,
        width: Double,
        maxLines: Int,
        ellipsizeMode: String?,
        anchorToCapHeight: Boolean,
        includeLines: Boolean,
        baseOffset: Int = 0,
    ): LayoutInfo {
        if (prepared.text.isEmpty()) {
            return LayoutInfo(
                height = prepared.style.fallbackLineHeight,
                lastLineWidth = 0.0,
                lineCount = 0.0,
                lines = emptyList(),
                width = 0.0,
            )
        }

        val density = currentDensity()
        val layoutWidth = max(0.0, width) * density
        val textWidthPx = max(1, ceil(layoutWidth).toInt())
        val charSequence = prepared.textWithLineHeight
        val paint = TextPaint(prepared.style.textPaint)
        val effectiveMaxLines = if (maxLines > 0) maxLines else Int.MAX_VALUE
        val ellipsize = resolveEllipsize(ellipsizeMode, effectiveMaxLines)

        val layout =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StaticLayout.Builder.obtain(charSequence, 0, charSequence.length, paint, textWidthPx)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setBreakStrategy(prepared.style.textBreakStrategy)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
                    .setIncludePad(prepared.style.includeFontPadding)
                    .setMaxLines(effectiveMaxLines)
                    .setEllipsize(ellipsize)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                StaticLayout(
                    charSequence,
                    paint,
                    textWidthPx,
                    Layout.Alignment.ALIGN_NORMAL,
                    1f,
                    0f,
                    prepared.style.includeFontPadding,
                )
            }

        val actualLineCount = min(layout.lineCount, effectiveMaxLines)
        val capHeightInsets =
            if (anchorToCapHeight) {
                val defaultCapHeightPx = measureCapHeightPx(paint)
                resolveCapHeightInsetsPx(
                    layout = layout,
                    text = charSequence,
                    defaultCapHeightPx = defaultCapHeightPx,
                    uniformCapHeightPx = prepared.uniformCapHeightPx ?: resolveUniformCapHeightPx(charSequence, defaultCapHeightPx),
                )
            } else {
                null
            }
        val topInsetPx = capHeightInsets?.top ?: 0f
        var widestLine = 0.0
        var lastLineWidth = 0.0
        var measuredHeight = layout.height.toDouble() / density
        var hasEllipsizedLine = false
        val lines = if (includeLines) ArrayList<LineInfo>(actualLineCount) else emptyList<LineInfo>()

        for (index in 0 until actualLineCount) {
            val lineStart = layout.getLineStart(index)
            val lineEnd = trimVisibleEnd(charSequence, lineStart, layout.getLineVisibleEnd(index))
            val isEllipsizedLine = layout.getEllipsisCount(index) > 0
            val lineWidthPx =
                if (isEllipsizedLine) {
                    min(layout.width.toFloat(), resolveMeasuredLineWidthPx(layout, charSequence, index))
                } else if (prepared.hasInlineStyleRuns) {
                    resolveMeasuredLineWidthPx(layout, charSequence, index)
                } else {
                    resolvePlainTextLineWidthPx(paint, prepared.text, lineStart, lineEnd)
                }
            val lineWidth = lineWidthPx.toDouble() / density
            val lineBottom =
                if (anchorToCapHeight) {
                    (layout.getLineBaseline(index) - topInsetPx).toDouble() / density
                } else {
                    layout.getLineBottom(index).toDouble() / density
                }
            hasEllipsizedLine = hasEllipsizedLine || isEllipsizedLine
            widestLine = max(widestLine, lineWidth)
            lastLineWidth = lineWidth
            measuredHeight = lineBottom

            if (includeLines) {
                (lines as ArrayList).add(
                    LineInfo(
                        bottom = lineBottom,
                        end = (baseOffset + lineEnd).toDouble(),
                        start = (baseOffset + lineStart).toDouble(),
                        width = lineWidth,
                    ),
                )
            }
        }

        if (hasEllipsizedLine) {
            widestLine = max(widestLine, layout.width.toDouble() / density)
        }

        return LayoutInfo(
            height = measuredHeight,
            lastLineWidth = lastLineWidth,
            lineCount = actualLineCount.toDouble(),
            lines = lines,
            width = widestLine,
        )
    }

    private fun measureIntrinsicWidth(prepared: PreparedTextData): Double {
        if (prepared.text.isEmpty()) return 0.0

        val text = prepared.textWithLineHeight
        val paint = TextPaint(prepared.style.textPaint)
        val boring = BoringLayout.isBoring(text, paint)
        val layout =
            if (boring != null) {
                BoringLayout.make(
                    text,
                    paint,
                    max(boring.width, 0),
                    Layout.Alignment.ALIGN_NORMAL,
                    1f,
                    0f,
                    boring,
                    prepared.style.includeFontPadding,
                )
            } else {
                buildStaticLayout(
                    text = text,
                    paint = paint,
                    widthPx = max(1, ceil(Layout.getDesiredWidth(text, paint).toDouble()).toInt()),
                    style = prepared.style,
                    maxLines = Int.MAX_VALUE,
                    ellipsizeMode = null,
                )
            }

        return resolveMeasuredLayoutWidthPx(layout, text).toDouble().toDp()
    }

    private fun buildStaticLayout(
        text: CharSequence,
        paint: TextPaint,
        widthPx: Int,
        style: ResolvedTextStyle,
        maxLines: Int,
        ellipsizeMode: String?,
        start: Int = 0,
        end: Int = text.length,
    ): Layout {
        return buildStaticLayoutCompat(
            text = text,
            paint = paint,
            widthPx = widthPx,
            includeFontPadding = style.includeFontPadding,
            breakStrategy = style.textBreakStrategy,
            hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NORMAL,
            maxLines = maxLines,
            ellipsize = resolveEllipsize(ellipsizeMode, maxLines),
            start = start,
            end = end,
        )
    }

    private fun resolveMeasuredLayoutWidthPx(layout: Layout, text: CharSequence): Float {
        var widestLineWidth = 0f

        for (index in 0 until layout.lineCount) {
            widestLineWidth = max(widestLineWidth, resolveMeasuredLineWidthPx(layout, text, index))
        }

        return widestLineWidth
    }

    private fun resolveMeasuredLineWidthPx(layout: Layout, text: CharSequence, index: Int): Float {
        val lineStart = layout.getLineStart(index)
        val lineVisibleEnd = layout.getLineVisibleEnd(index)
        val visibleEnd = trimVisibleEnd(text, lineStart, layout.getLineVisibleEnd(index))
        if (visibleEnd <= lineStart) return 0f

        val lineEnd = layout.getLineEnd(index)
        if (visibleEnd < lineVisibleEnd || visibleEnd < lineEnd) {
            val visibleWidth = max(0f, layout.getPrimaryHorizontal(visibleEnd) - layout.getLineLeft(index))
            return if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                ceil(visibleWidth.toDouble()).toFloat()
            } else {
                visibleWidth
            }
        }

        val endsWithNewLine = text.isNotEmpty() && lineEnd > 0 && text[lineEnd - 1] == '\n'
        return if (endsWithNewLine) {
            roundMeasuredTextWidthPx(layout.getLineMax(index))
        } else {
            roundMeasuredTextWidthPx(layout.getLineWidth(index))
        }
    }

    private fun packLayout(layout: LayoutInfo): DoubleArray {
        val packed = DoubleArray(PACKED_LAYOUT_SIZE)
        packLayoutInto(packed, 0, layout)
        return packed
    }

    private fun packLayoutInto(target: DoubleArray, offset: Int, layout: LayoutInfo) {
        target[offset] = layout.width
        target[offset + 1] = layout.height
        target[offset + 2] = layout.lineCount
        target[offset + 3] = layout.lastLineWidth
    }

    private fun packLayoutWithLines(layout: LayoutInfo): DoubleArray {
        val packed = DoubleArray(PACKED_LAYOUT_SIZE + layout.lines.size * PACKED_LINE_SIZE)
        packed[0] = layout.width
        packed[1] = layout.height
        packed[2] = layout.lineCount
        packed[3] = layout.lastLineWidth

        layout.lines.forEachIndexed { index, line ->
            val offset = PACKED_LAYOUT_SIZE + index * PACKED_LINE_SIZE
            packed[offset] = line.start
            packed[offset + 1] = line.end
            packed[offset + 2] = line.width
            packed[offset + 3] = line.bottom
        }

        return packed
    }

    private fun requirePrepared(handle: Long): PreparedTextData {
        return preparedTexts[handle] ?: error("RNTextEngine: attempted to use an invalid prepared text handle.")
    }

    @JvmStatic
    internal fun resolvePreparedTextViewData(handle: Long): PreparedTextViewData? {
        val prepared = preparedTexts[handle] ?: return null
        return resolvePreparedTextViewData(prepared, mountPlainTextNatively = false)
    }

    internal fun buildTextViewDisplayData(
        text: String,
        textTransform: String?,
        color: Int?,
        fontFamily: String?,
        fontSize: Double,
        fontWeight: String?,
        fontStyle: String?,
        letterSpacing: Double,
        lineHeight: Double,
        allowFontScaling: Boolean,
        includeFontPadding: Boolean = false,
        tabularNumbers: Boolean,
        textBreakStrategy: String?,
        runs: List<RNTextEngineTextRun> = emptyList(),
    ): PreparedTextViewData {
        val colorString = color?.toColorString()
        val baseStyle =
            resolveTextStyle(
                color = colorString,
                fontFamily = fontFamily,
                fontSize = fontSize,
                fontWeight = fontWeight,
                fontStyle = fontStyle,
                letterSpacing = letterSpacing,
                lineHeight = lineHeight,
                allowFontScaling = allowFontScaling,
                includeFontPadding = includeFontPadding,
                tabularNumbers = tabularNumbers,
                textBreakStrategy = textBreakStrategy,
            )
        val prepared =
            if (runs.isEmpty()) {
                buildPreparedTextForTextView(text, textTransform, baseStyle)
            } else {
                val measureRuns =
                    runs.map { run ->
                        TextMeasureRun(
                            end = run.end,
                            start = run.start,
                            style =
                                TextMeasureRunStyle(
                                    color = run.style.color,
                                    fontFamily = run.style.fontFamily,
                                    fontSize = run.style.fontSize,
                                    fontStyle = run.style.fontStyle,
                                    fontWeight = run.style.fontWeight,
                                    hasColor = run.style.hasColor,
                                    hasFontFamily = run.style.hasFontFamily,
                                    hasFontSize = run.style.hasFontSize,
                                    hasFontStyle = run.style.hasFontStyle,
                                    hasFontWeight = run.style.hasFontWeight,
                                    hasLetterSpacing = run.style.hasLetterSpacing,
                                    hasLineHeight = run.style.hasLineHeight,
                                    hasTabularNumbers = run.style.hasTabularNumbers,
                                    letterSpacing = run.style.letterSpacing,
                                    lineHeight = run.style.lineHeight,
                                    tabularNumbers = run.style.tabularNumbers,
                                ),
                        )
                    }

                buildPreparedTextForTextView(text, textTransform, baseStyle, measureRuns) { runStyle ->
                    resolveTextStyle(
                        color = if (runStyle.hasColor) runStyle.color else colorString,
                        fontFamily = if (runStyle.hasFontFamily) runStyle.fontFamily else fontFamily,
                        fontSize = if (runStyle.hasFontSize) runStyle.fontSize else fontSize,
                        fontWeight = if (runStyle.hasFontWeight) runStyle.fontWeight else fontWeight,
                        fontStyle = if (runStyle.hasFontStyle) runStyle.fontStyle else fontStyle,
                        letterSpacing = if (runStyle.hasLetterSpacing) runStyle.letterSpacing else letterSpacing,
                        lineHeight = if (runStyle.hasLineHeight) runStyle.lineHeight else lineHeight,
                        allowFontScaling = allowFontScaling,
                        includeFontPadding = includeFontPadding,
                        tabularNumbers = if (runStyle.hasTabularNumbers) runStyle.tabularNumbers else tabularNumbers,
                        textBreakStrategy = textBreakStrategy,
                    )
                }
            }

        return resolvePreparedTextViewData(prepared, mountPlainTextNatively = runs.isEmpty())
    }

    private fun resolvePreparedTextViewData(prepared: PreparedTextData, mountPlainTextNatively: Boolean): PreparedTextViewData {
        val baseCapHeightPx = measureCapHeightPx(TextPaint(prepared.style.textPaint))
        val mountNatively = mountPlainTextNatively && !prepared.hasInlineStyleRuns
        return PreparedTextViewData(
            baseCapHeightPx = baseCapHeightPx,
            includeFontPadding = prepared.style.includeFontPadding,
            lineHeightPx = if (mountNatively) prepared.style.lineHeightPx else null,
            mountMode = if (mountNatively) TextMountMode.NATIVE else TextMountMode.SPANNABLE,
            text = if (mountNatively) prepared.text else SpannableString.valueOf(prepared.textWithLineHeight),
            textColor = prepared.style.textColor,
            textPaint = TextPaint(prepared.style.textPaint),
            uniformCapHeightPx = prepared.uniformCapHeightPx ?: resolveUniformCapHeightPx(prepared.textWithLineHeight, baseCapHeightPx),
        )
    }

    @JvmStatic
    fun transformTextWithBoundaries(text: String, textTransform: String?, boundaries: IntArray?): Array<Any> {
        val resolvedBoundaries = boundaries ?: IntArray(0)
        val transformed = transformText(text, textTransform, resolvedBoundaries.toList())
        val mappedBoundaries =
            IntArray(resolvedBoundaries.size) { index ->
                transformed.offsetsByOriginal[resolvedBoundaries[index]] ?: resolvedBoundaries[index]
            }
        return arrayOf(transformed.text, mappedBoundaries)
    }

    private fun resolveTypeface(fontFamily: String?, fontWeight: String?, fontStyle: String?): Typeface {
        val style = resolveTypefaceStyle(fontWeight, fontStyle)
        if (fontFamily == null) {
            return Typeface.defaultFromStyle(style)
        }

        return ReactFontManager.getInstance().getTypeface(fontFamily, style, reactContext.assets)
            ?: Typeface.defaultFromStyle(style)
    }

    private fun resolveTypefaceStyle(fontWeight: String?, fontStyle: String?): Int {
        var style = if (fontStyle == "italic") Typeface.ITALIC else Typeface.NORMAL
        val weight = fontWeight ?: return style
        if (parseFontWeight(weight) >= 500) {
            style = style or Typeface.BOLD
        }
        return style
    }

    @android.annotation.SuppressLint("ObsoleteSdkInt")
    private fun resolveTextBreakStrategy(value: String?): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return 0
        return when (value) {
            "balanced" -> Layout.BREAK_STRATEGY_BALANCED
            "simple" -> Layout.BREAK_STRATEGY_SIMPLE
            else -> Layout.BREAK_STRATEGY_HIGH_QUALITY
        }
    }

    private fun resolveTextColor(value: String?): Int? {
        return RNTextEngineColorParser.parse(value)
    }

    private fun resolveEllipsize(mode: String?, maxLines: Int): TextUtils.TruncateAt? {
        if (maxLines <= 0 || maxLines == Int.MAX_VALUE) return null
        return when (mode) {
            "clip" -> null
            "head" -> TextUtils.TruncateAt.START
            "middle" -> TextUtils.TruncateAt.MIDDLE
            else -> TextUtils.TruncateAt.END
        }
    }

    private fun scale(value: Double, allowFontScaling: Boolean, defaultValue: Double): Float {
        val measure = if (value.isNaN()) defaultValue else value
        return if (allowFontScaling) PixelUtil.toPixelFromSP(measure.toFloat()) else PixelUtil.toPixelFromDIP(measure.toFloat())
    }

    private fun Int.toColorString(): String {
        val unsigned = toLong() and 0xFFFFFFFFL
        return "#${unsigned.toString(16).padStart(8, '0')}"
    }

    @JvmStatic
    fun currentFontScaleMultiplier(): Double {
        if (!::reactContext.isInitialized) return 1.0
        val fontScale = reactContext.resources.configuration.fontScale
        return if (fontScale > 0f) fontScale.toDouble() else 1.0
    }

    private fun currentDensity(): Double {
        return DisplayMetricsHolder.getWindowDisplayMetrics().density.toDouble()
    }

    private fun Double.toDp(): Double {
        return this / currentDensity()
    }

    private const val PACKED_LAYOUT_SIZE = 4
    private const val PACKED_LINE_SIZE = 4
    private const val RUN_STYLE_HAS_COLOR = 1 shl 0
    private const val RUN_STYLE_HAS_FONT_FAMILY = 1 shl 1
    private const val RUN_STYLE_HAS_FONT_SIZE = 1 shl 2
    private const val RUN_STYLE_HAS_FONT_STYLE = 1 shl 3
    private const val RUN_STYLE_HAS_FONT_WEIGHT = 1 shl 4
    private const val RUN_STYLE_HAS_LETTER_SPACING = 1 shl 5
    private const val RUN_STYLE_HAS_LINE_HEIGHT = 1 shl 6
    private const val RUN_STYLE_HAS_TABULAR_NUMBERS = 1 shl 7
}
