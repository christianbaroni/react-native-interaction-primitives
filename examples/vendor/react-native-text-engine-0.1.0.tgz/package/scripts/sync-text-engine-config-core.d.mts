import type { TextEngineDefaults } from '../src/types';

export type SyncTextEngineDefaultsResult = {
  configPath: string | null;
  defaults: TextEngineDefaults;
  wroteFiles: string[];
};

export function findTextEngineConfigPath(appRoot: string): string | null;
export function normalizeTextEngineDefaults(value: unknown, sourceLabel: string): TextEngineDefaults;
export function loadTextEngineDefaults(appRoot: string, packageRoot: string): {
  configPath: string | null;
  defaults: TextEngineDefaults;
};
export function buildTextEngineDefaultsArtifacts(
  packageRoot: string,
  defaults: TextEngineDefaults
): Array<{ contents: string; path: string }>;
export function syncTextEngineDefaults(args: { appRoot: string; packageRoot: string }): SyncTextEngineDefaultsResult;
