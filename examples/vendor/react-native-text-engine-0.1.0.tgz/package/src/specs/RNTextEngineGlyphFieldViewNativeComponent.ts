import { codegenNativeComponent, type ViewProps } from 'react-native';
import type { Double } from 'react-native/Libraries/Types/CodegenTypes';

export interface NativeProps extends ViewProps {
  handle?: Double;
}

export default codegenNativeComponent<NativeProps>('RNTextEngineGlyphFieldView');
