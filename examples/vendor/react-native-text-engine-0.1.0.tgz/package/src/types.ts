/**
 * Serializable handle for one prepared native text block.
 *
 * `PreparedText` implements this shape, and the worklet helpers return it for
 * cross-runtime transport.
 */
export type PreparedTextHandle = Readonly<{
  handle: number;
}>;

/**
 * Serializable handle for one native glyph field.
 *
 * `GlyphField` implements this shape, and worklet helpers accept it anywhere a
 * numeric glyph-field handle is valid.
 */
export type GlyphFieldHandle = Readonly<{
  handle: number;
}>;

/**
 * Small, high-value subset of RN text style used for prepared text ownership.
 *
 * The same style object feeds exact measurement and the prepared-handle render
 * surfaces, so only facts that materially affect layout or that render surface
 * belong here.
 */
export type TextMeasureStyle = {
  allowFontScaling?: boolean;
  color?: string;
  fontFamily?: string;
  fontSize?: number;
  fontStyle?: 'italic' | 'normal';
  fontWeight?: string;
  includeFontPadding?: boolean;
  letterSpacing?: number;
  lineHeight?: number;
  tabularNumbers?: boolean;
  textBreakStrategy?: 'balanced' | 'highQuality' | 'simple';
};

/**
 * Inline text-style overrides that can vary within one prepared text block.
 *
 * Block-level layout policy such as `allowFontScaling`, `includeFontPadding`,
 * and `textBreakStrategy` remains owned by the base `TextMeasureStyle`.
 */
export type TextMeasureRunStyle = Pick<
  TextMeasureStyle,
  'color' | 'fontFamily' | 'fontSize' | 'fontStyle' | 'fontWeight' | 'letterSpacing' | 'lineHeight' | 'tabularNumbers'
>;

/**
 * UTF-16 range-local style override inside one prepared text block.
 *
 * Runs must be sorted, non-overlapping, and remain within the source text's
 * UTF-16 bounds. `style` is a patch over the base `TextMeasureStyle`.
 */
export type TextMeasureRun = Readonly<{
  end: number;
  start: number;
  style: TextMeasureRunStyle;
}>;

/**
 * App-wide build-time text policy applied anywhere the caller leaves a
 * corresponding text fact unspecified.
 *
 * These defaults intentionally cover stable typography policy, not volatile
 * per-call geometry such as widths or offsets.
 */
export type TextEngineDefaults = TextMeasureStyle & {
  /**
   * Aligns text bands to the first visible line's cap top and the last visible
   * line's baseline whenever the relevant API leaves that choice unspecified.
   */
  anchorToCapHeight?: boolean;
};

/**
 * Width-constrained layout request against a prepared text block.
 */
export type LayoutOptions = {
  /**
   * Aligns the returned layout band to the first line's cap top and the last
   * visible line's baseline.
   *
   * This trims only the outer top and bottom edges of the full text block.
   * Inter-line spacing remains unchanged.
   */
  anchorToCapHeight?: boolean;
  ellipsizeMode?: 'clip' | 'head' | 'middle' | 'tail';
  maxLines?: number;
  width: number;
};

/**
 * Aggregate layout metrics for one text block at one width.
 *
 * When `LayoutOptions.anchorToCapHeight` is enabled, `height` reports the band
 * from the first visible line's cap top to the last visible line's baseline.
 */
export type TextLayout = {
  height: number;
  lastLineWidth: number;
  lineCount: number;
  width: number;
};

/**
 * Visible line geometry reported by the native text engine.
 *
 * `start` and `end` are UTF-16 offsets into the original string, matching
 * React Native/native string indexing semantics. `width` tracks the visible
 * line extent, so trailing whitespace trimmed from `end` does not widen it.
 * `bottom` is measured from the full block's top edge; when
 * `LayoutOptions.anchorToCapHeight` is enabled, that top edge is the first
 * visible line's cap top.
 */
export type TextLine = {
  bottom: number;
  end: number;
  index: number;
  start: number;
  width: number;
};

/**
 * One width-constrained visible line beginning at a caller-provided text offset.
 *
 * `start` and `end` are absolute UTF-16 offsets into the original text.
 * `width` tracks the visible line extent, so trailing whitespace trimmed from
 * `end` does not widen it. `bottom` is measured from that line's top edge; when
 * `NextLineOptions.anchorToCapHeight` is enabled, that top edge is the line's
 * cap top.
 */
export type NextTextLine = {
  bottom: number;
  end: number;
  start: number;
  width: number;
};

/**
 * Full line geometry result for one width-constrained text block.
 */
export type TextLayoutLines = TextLayout & {
  lines: TextLine[];
};

/**
 * Stable per-variant drawing override inside a glyph field.
 *
 * Glyph fields own geometry separately from text layout, so variants only
 * describe how one cell draws, not how lines break.
 */
export type GlyphFieldVariant = {
  color: string;
  fontStyle?: 'italic' | 'normal';
  fontWeight?: string;
};

/**
 * Stable geometry and styling contract for a native glyph field.
 *
 * `columns` × `rows` defines the fixed cell count. Each cell is updated later
 * through `GlyphField.update()` with either one UTF-16 code unit in `glyphs`
 * or one byte index into `glyphPalette`, plus one variant index in
 * `variantIndices`.
 */
export type GlyphFieldConfig = {
  columns: number;
  fontFamily?: string;
  fontSize?: number;
  glyphPalette?: string;
  letterSpacing?: number;
  lineHeight?: number;
  rows: number;
  textAlign?: 'center' | 'left' | 'right';
  variants: readonly GlyphFieldVariant[];
};
