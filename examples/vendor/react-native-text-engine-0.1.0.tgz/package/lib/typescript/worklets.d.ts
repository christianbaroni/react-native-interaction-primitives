import { type WorkletRuntime } from 'react-native-worklets';
import type { GlyphFieldHandle, LayoutOptions, NextTextLine, PreparedTextHandle, TextLayout, TextMeasureRun, TextMeasureStyle } from './types';
declare global {
    var _WORKLET_RUNTIME: ArrayBuffer;
    var __RNTextEngineCommitGlyphFieldBuffers: ((handle: number) => void) | undefined;
    var __RNTextEngineCreateGlyphFieldBuffers: ((handle: number) => {
        glyphIndices: ArrayBuffer;
        variantIndices: ArrayBuffer;
    }) | undefined;
    var __RNTextEngineInstallWorkletRuntime: ((workletRuntime: object) => boolean) | undefined;
    var __RNTextEngineUpdateGlyphField: ((handle: number, glyphs: string, variantIndices: Uint8Array) => void) | undefined;
    var __RNTextEngineUpdateGlyphFieldIndices: ((handle: number, glyphIndices: Uint8Array, variantIndices: Uint8Array) => void) | undefined;
}
export type TextEngineRuntimeConfig = {
    animationQueuePollingRate?: number;
    initializer?: () => void;
    name?: string;
    useDefaultQueue?: boolean;
    customQueue?: object;
    enableEventLoop?: true;
};
export type GlyphFieldRuntimeBuffers = {
    glyphIndices: Uint8Array;
    variantIndices: Uint8Array;
};
/**
 * Installs `react-native-text-engine` into the Reanimated UI runtime.
 *
 * Call this once during app startup before running text-engine calls from UI
 * worklets.
 */
export declare function installTextEngineInUIRuntime(): void;
/**
 * Creates a dedicated Worklets runtime and installs `react-native-text-engine`
 * into it before any caller initializer runs.
 */
export declare function createTextEngineRuntime(config?: TextEngineRuntimeConfig): WorkletRuntime;
/**
 * Worklet-safe exact batch measurement against the current installed runtime.
 *
 * This must be called only after `react-native-text-engine` has been installed into
 * the current runtime.
 */
export declare function measureTextsInRuntime(texts: readonly string[], style: TextMeasureStyle | undefined, options: LayoutOptions, runsByText?: readonly (readonly TextMeasureRun[] | undefined)[]): TextLayout[];
/**
 * Worklet-safe prepared-text creation against the current installed runtime.
 */
export declare function createPreparedTextsInRuntime(texts: readonly string[], style?: TextMeasureStyle, runsByText?: readonly (readonly TextMeasureRun[] | undefined)[]): PreparedTextHandle[];
/**
 * Worklet-safe prepared-text layout against the current installed runtime.
 */
export declare function layoutPreparedTextsInRuntime(handles: readonly PreparedTextHandle[], options: LayoutOptions): TextLayout[];
/**
 * Worklet-safe single-line layout against the current installed runtime.
 *
 * Use this when line width changes one line at a time, such as flowing text
 * around animated obstacles.
 */
export declare function layoutNextLineInRuntime(handle: PreparedTextHandle | number, start: number, width: number, anchorToCapHeight?: boolean): NextTextLine | null;
/**
 * Worklet-safe glyph-field update against the current installed runtime.
 */
export declare function updateGlyphFieldInRuntime(handle: GlyphFieldHandle | number, glyphs: string, variantIndices: Uint8Array): void;
export declare function updateGlyphFieldInRuntime(handle: GlyphFieldHandle | number, glyphIndices: Uint8Array, variantIndices: Uint8Array): void;
export declare function createGlyphFieldBuffersInRuntime(handle: GlyphFieldHandle | number): GlyphFieldRuntimeBuffers;
export declare function commitGlyphFieldBuffersInRuntime(handle: GlyphFieldHandle | number): void;
