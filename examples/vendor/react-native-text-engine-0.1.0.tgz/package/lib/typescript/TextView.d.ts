import { type ReactNode } from 'react';
import type { StyleProp, TextStyle, ViewStyle } from 'react-native';
import { type NativeProps as NativeTextViewProps } from './specs/RNTextEngineTextViewNativeComponent';
import type { TextMeasureRun } from './types';
export type TextViewRunPayload = Readonly<{
    runColors?: readonly string[];
    runCount?: number;
    runEnds: readonly number[];
    runFontFamilies?: readonly string[];
    runFontSizes?: readonly number[];
    runFontStyles?: readonly string[];
    runFontWeights?: readonly string[];
    runLetterSpacings?: readonly number[];
    runLineHeights?: readonly number[];
    runStarts: readonly number[];
    runStyleMasks?: readonly number[];
    runTabularNumbers?: readonly boolean[];
}>;
/**
 * Props for the native text display surface.
 *
 * `TextView` is the canonical zero-extra-work render surface. Pass `text`
 * directly on hot paths. The Babel plugin lowers textual JSX children into
 * this prop when it can prove the child model, and uses narrowly-scoped
 * runtime helpers only for dynamic child forwarding boundaries that JSX alone
 * cannot lower losslessly for a custom text host.
 */
type InternalTextViewPropKey = 'rnteHasAllowFontScaling' | 'rnteHasLetterSpacing' | 'rnteHasTabularNumbers' | 'rnteIsVirtualTextSpan';
export type TextViewProps = Omit<NativeTextViewProps, 'style' | InternalTextViewPropKey> & {
    children?: ReactNode;
    style?: StyleProp<ViewStyle & TextStyle>;
};
/**
 * Flattens inline runs into the canonical `TextView` prop payload.
 *
 * Call this where the run list is owned or memoized. `TextView` itself does no
 * render-time run packing.
 */
export declare function createTextViewRunPayload(runs: readonly TextMeasureRun[] | undefined): TextViewRunPayload | undefined;
/**
 * Native text display surface that can be driven directly by animated props.
 */
export declare const TextView: import("react").ForwardRefExoticComponent<Omit<NativeTextViewProps, "style" | InternalTextViewPropKey> & {
    children?: ReactNode;
    style?: StyleProp<ViewStyle & TextStyle>;
} & import("react").RefAttributes<any>>;
export {};
