import { type NativeProps as NativeGlyphFieldViewProps } from './specs/RNTextEngineGlyphFieldViewNativeComponent';
/**
 * Props for the native glyph-field render surface.
 *
 * The view renders whatever content currently lives in the referenced
 * `GlyphFieldHandle`. Geometry and variant policy are owned by that handle.
 */
export type GlyphFieldViewProps = NativeGlyphFieldViewProps;
export declare const GlyphFieldView: import("react").ForwardRefExoticComponent<NativeGlyphFieldViewProps & import("react").RefAttributes<any>>;
