import { type ViewProps } from 'react-native';
import type { Double } from 'react-native/Libraries/Types/CodegenTypes';
export interface NativeProps extends ViewProps {
    handle?: Double;
}
declare const _default: HostComponent<Props>;
export default _default;
