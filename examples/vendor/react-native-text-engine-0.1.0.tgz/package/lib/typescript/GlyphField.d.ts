import type { GlyphFieldConfig, GlyphFieldHandle } from './types';
export declare class GlyphField implements GlyphFieldHandle {
    readonly handle: number;
    private constructor();
    static fromHandle(handle: number): GlyphField;
    update(glyphs: string, variantIndices: Uint8Array): void;
    update(glyphIndices: Uint8Array, variantIndices: Uint8Array): void;
    release(): void;
    static create(config: GlyphFieldConfig): GlyphField;
}
export declare function createGlyphField(config: GlyphFieldConfig): GlyphField;
