/**
 * Coerces one dynamic text expression into the canonical `text` prop surface.
 *
 * This is intentionally strict: text expressions may vanish (`null`/booleans)
 * or produce textual primitives, but they may not smuggle React nodes or
 * objects through the direct-text path.
 */
export declare function coerceTextViewText(value: unknown): string;
