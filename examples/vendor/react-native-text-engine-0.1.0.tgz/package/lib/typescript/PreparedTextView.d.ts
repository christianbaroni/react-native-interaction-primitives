import { type NativeProps as NativePreparedTextViewProps } from './specs/RNTextEnginePreparedTextViewNativeComponent';
/**
 * Props for the native prepared-handle render surface.
 *
 * `selectable` opts into the interaction-oriented native text owner.
 *
 * `anchorToCapHeight` aligns the view band from the first line's cap top to
 * the last visible line's baseline without trimming ascenders or descenders
 * outside that band.
 */
export type PreparedTextViewProps = NativePreparedTextViewProps & {
    ellipsizeMode?: 'clip' | 'head' | 'middle' | 'tail';
    handle?: number;
    numberOfLines?: number;
};
/**
 * Native prepared-handle render surface.
 */
export declare const PreparedTextView: import("react").ForwardRefExoticComponent<NativePreparedTextViewProps & {
    ellipsizeMode?: "clip" | "head" | "middle" | "tail";
    handle?: number;
    numberOfLines?: number;
} & import("react").RefAttributes<any>>;
