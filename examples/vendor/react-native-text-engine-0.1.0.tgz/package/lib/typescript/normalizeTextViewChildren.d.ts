import { type ComponentType, type ReactNode } from 'react';
type TextViewComponentType = ComponentType<{
    children?: ReactNode;
    text?: string;
}>;
/**
 * Lowers opaque ReactNode child forwarding into explicit `TextView` text spans.
 *
 * This keeps wrapper-style `<TextView>{children}</TextView>` usage lossless for
 * primitive text, arrays, fragments, and nested elements without making JS the
 * owner of final text flattening. Native still owns flattening the resulting
 * `TextView` subtree into one payload.
 */
export declare function normalizeTextViewChildren(children: ReactNode, TextViewComponent: TextViewComponentType): ReactNode;
export {};
