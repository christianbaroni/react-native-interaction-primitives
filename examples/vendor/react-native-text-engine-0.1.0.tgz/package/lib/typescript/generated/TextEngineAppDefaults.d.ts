import type { TextEngineDefaults } from '../types';
export declare const textEngineAppDefaults: TextEngineDefaults;
export default textEngineAppDefaults;
