import type { GlyphFieldConfig, LayoutOptions, TextMeasureStyle } from './types';
/**
 * Resolves app-wide build-time text defaults against a caller-provided style.
 *
 * The original object is preserved when no defaulted field needs filling.
 */
export declare function resolveTextMeasureStyle(style: TextMeasureStyle | undefined): TextMeasureStyle | undefined;
/**
 * Resolves the app-wide cap-height anchoring default for one caller-owned value.
 */
export declare function resolveAnchorToCapHeight(anchorToCapHeight: boolean | undefined): boolean | undefined;
export declare function shouldResolveAnchorToCapHeight(anchorToCapHeight: boolean | undefined): boolean;
/**
 * Resolves app-wide layout defaults against one width-constrained block layout request.
 */
export declare function resolveLayoutOptions(options: LayoutOptions): LayoutOptions;
/**
 * Resolves the glyph-field subset of the app-wide text defaults.
 *
 * `fontSize` and `lineHeight` stay required at the resolved boundary. If the
 * caller omits either one and no build-time default supplies it, the call is
 * rejected before native ownership begins.
 */
export declare function resolveGlyphFieldConfig(config: GlyphFieldConfig): GlyphFieldConfig;
