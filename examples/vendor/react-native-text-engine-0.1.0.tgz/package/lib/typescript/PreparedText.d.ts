import type { LayoutOptions, NextTextLine, PreparedTextHandle, TextLayout, TextLayoutLines, TextMeasureRun, TextMeasureStyle } from './types';
type RunsByText = readonly (readonly TextMeasureRun[] | undefined)[];
export declare class PreparedText implements PreparedTextHandle {
    readonly handle: number;
    private constructor();
    static fromHandle(handle: number): PreparedText;
    layout(options: LayoutOptions): TextLayout;
    lines(options: LayoutOptions): TextLayoutLines;
    nextLine(start: number, width: number, anchorToCapHeight?: boolean): NextTextLine | null;
    release(): void;
}
export declare function createPreparedText(text: string, style?: TextMeasureStyle, runs?: readonly TextMeasureRun[]): PreparedText;
export declare function createPreparedText(texts: readonly string[], style?: TextMeasureStyle, runsByText?: RunsByText): PreparedText[];
export declare function measureTextWidth(text: string, style?: TextMeasureStyle, runs?: readonly TextMeasureRun[]): number;
export declare function measureText(text: string, style: TextMeasureStyle | undefined, options: LayoutOptions, runs?: readonly TextMeasureRun[]): TextLayout;
export declare function measureText(texts: readonly string[], style: TextMeasureStyle | undefined, options: LayoutOptions, runsByText?: RunsByText): TextLayout[];
export declare function layoutPreparedText(handle: PreparedTextHandle, options: LayoutOptions): TextLayout;
export declare function layoutPreparedText(handles: readonly PreparedTextHandle[], options: LayoutOptions): TextLayout[];
export declare function releasePreparedText(handle: PreparedTextHandle): void;
export declare function releasePreparedText(handles: readonly PreparedTextHandle[]): void;
export {};
